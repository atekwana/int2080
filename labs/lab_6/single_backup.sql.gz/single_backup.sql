-- MySQL dump 10.13  Distrib 9.4.0, for Win64 (x86_64)
--
-- Host: localhost    Database: student_data
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `author` (
  `AuthorID` varchar(4) NOT NULL,
  `PubID` int DEFAULT NULL,
  `Lname` varchar(10) DEFAULT NULL,
  `Fname` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`AuthorID`),
  KEY `PubID` (`PubID`),
  CONSTRAINT `author_ibfk_1` FOREIGN KEY (`PubID`) REFERENCES `publisher` (`PubID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author`
--

LOCK TABLES `author` WRITE;
/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` VALUES ('A100',3,'AUSTIN','JAMES'),('A105',4,'ADAMS','JUAN'),('A200',4,'AUSTIN','JAMES'),('B100',3,'BAKER','JACK'),('F100',2,'FIELDS','OSCAR'),('J100',2,'JONES','JANICE'),('K100',5,'KZOCHSKY','TAMARA'),('M100',4,'MARTINEZ','SHEILA'),('P100',5,'PORTER','LISA'),('P105',2,'PETERSON','TINA'),('R100',5,'ROBINSON','ROBERT'),('S100',1,'SMITH','SAM'),('W100',1,'WHITE','WILLIAM'),('W105',3,'WHITE','LISA'),('W110',4,'WILKINSON','ANTHONY'),('W200',2,'WHITE','LISA');
/*!40000 ALTER TABLE `author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `BookID` int NOT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `AuthorID` varchar(4) DEFAULT NULL,
  `PubID` int DEFAULT NULL,
  `Customer_no` int DEFAULT NULL,
  PRIMARY KEY (`BookID`),
  KEY `AuthorID` (`AuthorID`),
  KEY `PubID` (`PubID`),
  KEY `Customer_no` (`Customer_no`),
  CONSTRAINT `books_ibfk_1` FOREIGN KEY (`AuthorID`) REFERENCES `author` (`AuthorID`),
  CONSTRAINT `books_ibfk_2` FOREIGN KEY (`PubID`) REFERENCES `publisher` (`PubID`),
  CONSTRAINT `books_ibfk_3` FOREIGN KEY (`Customer_no`) REFERENCES `customers` (`Customer_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1001,'Database Design','S100',1,1001),(1002,'Web Development','J100',2,1002),(1003,'Java Programming','A100',3,1003),(1004,'Data Structures','M100',4,1004),(1005,'SQL Basics','K100',5,1005),(1006,'Python Guide','P100',5,1006),(1007,'Machine Learning','A105',4,1007),(1008,'Cloud Computing','B100',3,1008),(1009,'DevOps Manual','P105',2,1009),(1010,'Network Security','W100',1,1010);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `Customer_no` int NOT NULL AUTO_INCREMENT,
  `LastName` varchar(10) DEFAULT NULL,
  `FirstName` varchar(10) DEFAULT NULL,
  `Address` varchar(20) DEFAULT NULL,
  `City` varchar(12) DEFAULT NULL,
  `State` varchar(2) DEFAULT NULL,
  `Zip` varchar(5) DEFAULT NULL,
  `Referred` int DEFAULT NULL,
  `Region` char(2) DEFAULT NULL,
  PRIMARY KEY (`Customer_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1027 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1001,'MORALES','BONITA','P.O. BOX 651','EASTPOINT','FL','32328',NULL,'SE'),(1002,'THOMPSON','RYAN','P.O. BOX 9835','SANTA MONICA','CA','90404',NULL,'W'),(1003,'SMITH','LEILA','P.O. BOX 66','TALLAHASSEE','FL','32306',NULL,'SE'),(1004,'PIERSON','THOMAS','69821 SOUTH AVENUE','BOISE','ID','83707',NULL,'NW'),(1005,'GIRARD','CINDY','P.O. BOX 851','SEATTLE','WA','98115',NULL,'NW'),(1006,'CRUZ','MESHIA','82 DIRT ROAD','ALBANY','NY','12211',NULL,'NE'),(1007,'GIANA','TAMMY','9153 MAIN STREET','AUSTIN','TX','78710',1003,'SW'),(1008,'JONES','KENNETH','P.O. BOX 137','CHEYENNE','WY','82003',NULL,'N'),(1009,'PEREZ','JORGE','P.O. BOX 8564','BURBANK','CA','91510',1003,'W'),(1010,'LUCAS','JAKE','114 EAST SAVANNAH','ATLANTA','GA','30314',NULL,'SE'),(1011,'MCGOVERN','REESE','P.O. BOX 18','CHICAGO','IL','60606',NULL,'N'),(1012,'MCKENZIE','WILLIAM','P.O. BOX 971','BOSTON','MA','02110',NULL,'NE'),(1013,'NGUYEN','NICHOLAS','357 WHITE EAGLE AVE.','CLERMONT','FL','34711',1006,'SE'),(1014,'LEE','JASMINE','P.O. BOX 2947','CODY','WY','82414',NULL,'N'),(1015,'SCHELL','STEVE','P.O. BOX 677','MIAMI','FL','33111',NULL,'SE'),(1016,'DAUM','MICHELL','9851231 LONG ROAD','BURBANK','CA','91508',1010,'W'),(1017,'NELSON','BECCA','P.O. BOX 563','KALMAZOO','MI','49006',NULL,'N'),(1018,'MONTIASA','GREG','1008 GRAND AVENUE','MACON','GA','31206',NULL,'SE'),(1019,'SMITH','JENNIFER','P.O. BOX 1151','MORRISTOWN','NJ','07962',1003,'NE'),(1020,'FALAH','KENNETH','P.O. BOX 335','TRENTON','NJ','08607',NULL,'NE'),(1025,'SMITH','LEILA','P.O. BOX 66','TALLAHASSEE','FL','32306',NULL,'SE'),(1026,'GIANA','TAMMY','9153 MAIN STREET','AUSTIN','TX','78710',1003,'SW');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publisher`
--

DROP TABLE IF EXISTS `publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publisher` (
  `PubID` int NOT NULL,
  `Name` varchar(23) DEFAULT NULL,
  `Contact` varchar(15) DEFAULT NULL,
  `Phone` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`PubID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publisher`
--

LOCK TABLES `publisher` WRITE;
/*!40000 ALTER TABLE `publisher` DISABLE KEYS */;
INSERT INTO `publisher` VALUES (1,'PRINTING IS US','TOMMIE SEYMOUR','000-714-8321'),(2,'PUBLISH OUR WAY','JANE TOMLIN','010-410-0010'),(3,'AMERICAN PUBLISHING','DAVID DAVIDSON','800-555-1211'),(4,'READING MATERIALS INC.','RENEE SMITH','800-555-9743'),(5,'REED-N-RITE','SEBASTIAN JONES','800-555-8284'),(6,'AMERICAN PUBLISHING','SARAH JOHNSON','800-555-9999'),(7,'REED-N-RITE','MICHAEL BROWN','800-555-7777');
/*!40000 ALTER TABLE `publisher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-28 14:56:41
